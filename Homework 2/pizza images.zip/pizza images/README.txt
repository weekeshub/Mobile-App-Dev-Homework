License:
Creazilla Open-Source License. Free for personal and commercial use. No attribution required. More info.
https://creazilla.com/nodes/3986-set-of-pizza-3d-model